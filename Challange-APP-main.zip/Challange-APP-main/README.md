# Challange APP

sass & pug required, use the following commands to install:
```
sudo apt-get install pug-cli
sudo apt-get install sass
```

To generate HTML/CSS files, do
```
pug ./pre/pug/ -o ./html/ 
sass ./pre/sass:./css
```

The html's should be in html/, main page being index.html
Design templates are located in src/

Remember to name file with English and numbers only :)